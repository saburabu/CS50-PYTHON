#  Personal Greeting
name = input("What's your name? ")
age = int(input("How old are you? "))
print(f"Name: {name}".strip().title())
print(f"Age: {age}")

def greet(name, age):
    print(f"Hey {name}, you are {age} that's cool")


