for i in range(1, 6):       # vertical loop
    for j in range(i):  # horizontal loop
        print("*", end="")
    print()
