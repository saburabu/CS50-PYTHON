for numbers in range(1, 11):
    if numbers == 5:
        continue
    print(numbers)