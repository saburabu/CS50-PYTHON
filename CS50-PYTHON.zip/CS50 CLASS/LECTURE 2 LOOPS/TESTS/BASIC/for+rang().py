for numbers in range(1, 11):
    print(f"{numbers}")
# if you want the backwards
# method 1
for numbers in range(10, 0, -1):
    print(f"{numbers}")
for numbers in reversed(range(1, 11)):
    print(f"{numbers}")
