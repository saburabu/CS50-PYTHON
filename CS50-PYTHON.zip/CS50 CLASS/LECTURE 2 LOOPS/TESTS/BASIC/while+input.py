while True:
    password = str(input("Passsword: "))
    if password == "python123":
        break

print("correct!")
    

        
        
