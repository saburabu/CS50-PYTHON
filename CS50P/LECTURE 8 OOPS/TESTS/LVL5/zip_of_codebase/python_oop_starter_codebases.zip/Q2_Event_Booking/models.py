from __future__ import annotations

from dataclasses import dataclass, field


@dataclass
class Event:
    title: str
    venue: str
    date: str
    capacity: int
    bookings: list["Booking"] = field(default_factory=list)

    def spaces_left(self) -> int:
        return self.capacity - len(self.bookings)

    def add_booking(self, booking: "Booking") -> None:
        self.bookings.append(booking)

    def __str__(self) -> str:
        return f"{self.title} at {self.venue} on {self.date}"


class Attendee:
    def __init__(self, name: str, email: str) -> None:
        self.name = name
        self.__email = email
        self.bookings: list[Booking] = []

    @property
    def email(self) -> str:
        return self.__email

    def add_booking(self, booking: "Booking") -> None:
        self.bookings.append(booking)

    def __str__(self) -> str:
        return f"{self.name} <{self.email}>"


@dataclass
class Booking:
    reference: str
    attendee: Attendee
    event: Event
    status: str = "confirmed"

    def cancel(self) -> None:
        self.status = "cancelled"

    def __str__(self) -> str:
        return f"{self.reference}: {self.attendee.name} — {self.event.title} ({self.status})"
