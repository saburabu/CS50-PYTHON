from AUTHENTICATION.save_users_json import load_user as user

print(user)