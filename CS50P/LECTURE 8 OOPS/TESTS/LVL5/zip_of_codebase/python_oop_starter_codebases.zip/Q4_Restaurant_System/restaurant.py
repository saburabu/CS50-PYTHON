from dataclasses import dataclass, field

from menu import MenuItem


@dataclass
class Table:
    number: int
    seats: int
    current_order: "Order | None" = None

    def __str__(self) -> str:
        return f"Table {self.number} ({self.seats} seats)"


@dataclass
class Order:
    table: Table
    items: list[MenuItem] = field(default_factory=list)
    status: str = "open"

    def add_item(self, item: MenuItem) -> None:
        self.items.append(item)

    def total(self) -> float:
        return sum(item.price for item in self.items)

    def close(self) -> None:
        self.status = "closed"

    def __len__(self) -> int:
        return len(self.items)


class Restaurant:
    def __init__(self, name: str) -> None:
        self.name = name
        self.tables: list[Table] = []
        self.orders: list[Order] = []

    def add_table(self, table: Table) -> None:
        self.tables.append(table)

    def open_order(self, table: Table) -> Order:
        order = Order(table)
        table.current_order = order
        self.orders.append(order)
        return order

    def close_order(self, order: Order) -> float:
        order.close()
        return order.total()

    def table_summary(self, table: Table) -> str:
        if table.current_order is None:
            return f"{table}: no current order"
        return f"{table}: {len(table.current_order)} item(s), {table.current_order.status}"
