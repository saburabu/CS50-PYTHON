# Q2 — Event Booking System

## Scenario

You have inherited a small event booking program. It keeps events, attendees and bookings in memory. The program runs, but the behaviour and design do not consistently meet the specification below.

## Run it

Use Python 3.10 or later. From this folder, run:

```bash
python main.py
```

No packages need to be installed.

## Files

- `models.py` — event, attendee and booking domain objects
- `booking_system.py` — application service for registering and booking
- `main.py` — a short demonstration

## Requirements to implement

1. An event has a non-empty title, venue, date and a positive capacity.
2. An attendee has a non-empty name and a valid email address.
3. An attendee may hold at most one active booking for the same event.
4. A booking is confirmed only while the event has space available.
5. The number of confirmed bookings must never exceed the event capacity.
6. Cancelling a booking must update every relevant record and make the place available again.
7. A booking summary must show the correct attendee, event and current status.
8. The program should continue to use objects rather than parallel lists or dictionaries for its core state.

Keep the console demonstration working while you improve the design.
