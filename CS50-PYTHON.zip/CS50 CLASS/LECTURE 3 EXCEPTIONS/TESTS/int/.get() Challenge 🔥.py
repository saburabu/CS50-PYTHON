students = {
    "John": 85,
    "Sarah": 92,
    "Mike": 78
}
for student in students.items():
    print(f"{student}")