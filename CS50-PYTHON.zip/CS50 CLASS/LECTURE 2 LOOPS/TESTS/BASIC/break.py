while True:
    number = int(input("Number: "))
    if number == 0:
        break
    
for numbers in range(number):
    print(number)

print("Done!")