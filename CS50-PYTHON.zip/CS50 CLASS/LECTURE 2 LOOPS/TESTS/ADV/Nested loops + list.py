numbers = [2, 4, 6, 8]
for i in numbers:
    for j in numbers:
        print(i, j)