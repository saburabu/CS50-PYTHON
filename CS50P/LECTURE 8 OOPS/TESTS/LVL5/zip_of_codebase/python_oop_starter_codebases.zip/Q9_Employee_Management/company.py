from employees import Employee


class Company:
    def __init__(self, name: str) -> None:
        self.name = name
        self.employees: list[Employee] = []

    def add_employee(self, employee: Employee) -> None:
        self.employees.append(employee)

    def find_employee(self, employee_id: str) -> Employee | None:
        for employee in self.employees:
            if employee.employee_id == employee_id:
                return employee
        return None

    def remove_employee(self, employee_id: str) -> None:
        employee = self.find_employee(employee_id)
        if employee is None:
            raise LookupError("Employee not found.")
        self.employees.remove(employee)

    def payroll_report(self) -> str:
        lines = [f"Payroll for {self.name}"]
        total = 0.0
        for employee in self.employees:
            pay = employee.monthly_pay()
            total += pay
            lines.append(f"- {employee}: ₦{pay:,.2f}")
        lines.append(f"Total: ₦{total:,.2f}")
        return "\n".join(lines)
