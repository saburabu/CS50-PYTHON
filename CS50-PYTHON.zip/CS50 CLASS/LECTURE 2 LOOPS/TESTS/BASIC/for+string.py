for letter in "hello":
    print(f"{letter}")