names = []

for name in range(3):
    name = str(input("Name: "))
    names.append(name)

print(names)