from AUTHENTICATION.save_users_json import load_user
import requests , json

user = load_user()

#class InsufficientFundsError():

#class AccountDoesNotExistError():

#class  