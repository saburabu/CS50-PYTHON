def new_func():
    while True:
        numbers = [4, 11, 7, 20, 3, 15, 8]
        if numbers > 10:
            break 
    for _ in numbers:
        print(numbers)

new_func()