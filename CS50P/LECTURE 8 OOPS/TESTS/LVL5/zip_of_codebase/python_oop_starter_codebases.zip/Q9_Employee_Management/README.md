# Q9 — Employee Management System

## Scenario

You have been given an employee management application that needs to support a growing company. It stores different kinds of employees and produces payroll information. The current program runs, but it does not reliably satisfy the requirements below.

## Run it

Use Python 3.10 or later. From this folder, run:

```bash
python main.py
```

No packages need to be installed.

## Files

- `employees.py` — the employee hierarchy
- `company.py` — company collection and payroll operations
- `main.py` — a short demonstration

## Requirements to implement

1. Every employee has a unique ID, non-empty name and non-negative pay data.
2. Payroll must use the appropriate calculation for each employee type.
3. Salary information must not be freely replaceable with invalid values.
4. The company must not add the same employee ID more than once.
5. Searching by employee ID must return the matching employee or a clear result when absent.
6. Removing an employee must update the company records accurately.
7. The payroll report must show each employee once and calculate the correct total.
8. Add a `ContractEmployee` type that works with the same payroll-report code as the other employee types.

Keep the demonstration runnable and use inheritance and polymorphism where they fit.
