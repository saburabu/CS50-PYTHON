word = "programming"

for words in reversed(range(len(word))):
    print(word[words])