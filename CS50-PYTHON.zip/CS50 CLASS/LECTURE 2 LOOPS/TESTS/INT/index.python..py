word = "python"
for index, word in enumerate(word)  :
    print(word)
