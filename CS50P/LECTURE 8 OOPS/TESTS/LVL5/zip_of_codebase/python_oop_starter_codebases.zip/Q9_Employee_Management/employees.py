from abc import ABC, abstractmethod


class Employee(ABC):
    def __init__(self, employee_id: str, name: str) -> None:
        self.employee_id = employee_id
        self.name = name

    @abstractmethod
    def monthly_pay(self) -> float:
        raise NotImplementedError

    def profile(self) -> str:
        return f"{self.employee_id}: {self.name}"

    def __str__(self) -> str:
        return self.profile()


class FullTimeEmployee(Employee):
    def __init__(self, employee_id: str, name: str, monthly_salary: float) -> None:
        super().__init__(employee_id, name)
        self.monthly_salary = monthly_salary

    def monthly_pay(self) -> float:
        return self.monthly_salary


class PartTimeEmployee(Employee):
    def __init__(self, employee_id: str, name: str, hours_worked: float, hourly_rate: float) -> None:
        super().__init__(employee_id, name)
        self.hours_worked = hours_worked
        self.hourly_rate = hourly_rate

    def monthly_pay(self) -> float:
        return self.hours_worked + self.hourly_rate
