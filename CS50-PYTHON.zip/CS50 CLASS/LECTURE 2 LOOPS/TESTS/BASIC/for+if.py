for number in range(0, 21):
    if number % 2 != 0:
        continue
    print(f"{number}")