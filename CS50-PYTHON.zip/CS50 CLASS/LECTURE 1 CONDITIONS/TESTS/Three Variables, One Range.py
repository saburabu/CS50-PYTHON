a = int(input("A: "))
b = int(input("B: "))
c = int(input("C: "))

if (10 <= a <= 99) and (10 <= b <= 99) and (10<= c <= 99):
    print("VALID")
else:
    print("INVALID")