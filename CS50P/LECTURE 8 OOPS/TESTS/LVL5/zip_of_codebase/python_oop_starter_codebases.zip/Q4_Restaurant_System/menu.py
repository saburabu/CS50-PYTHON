from abc import ABC, abstractmethod


class MenuItem(ABC):
    def __init__(self, name: str, price: float) -> None:
        self.name = name
        self.price = price

    @abstractmethod
    def description(self) -> str:
        raise NotImplementedError

    def __str__(self) -> str:
        return f"{self.description()} - ₦{self.price:,.2f}"


class FoodItem(MenuItem):
    def __init__(self, name: str, price: float, is_spicy: bool) -> None:
        super().__init__(name, price)
        self.is_spicy = is_spicy

    def description(self) -> str:
        label = "spicy" if self.is_spicy else "mild"
        return f"{self.name} ({label} food)"


class DrinkItem(MenuItem):
    def __init__(self, name: str, price: float, size: str) -> None:
        super().__init__(name, price)
        self.size = size

    def description(self) -> str:
        return f"{self.name} ({self.size} drink)"
