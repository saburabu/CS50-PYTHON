from models import Attendee, Booking, Event


class BookingSystem:
    def __init__(self) -> None:
        self.events: list[Event] = []
        self.bookings: list[Booking] = []
        self._next_reference = 100

    def register_event(self, event: Event) -> None:
        self.events.append(event)

    def make_booking(self, attendee: Attendee, event: Event) -> Booking:
        if event.spaces_left() < 0:
            raise ValueError("This event is full.")

        reference = f"BK-{self._next_reference}"
        self._next_reference += 1
        booking = Booking(reference, attendee, event)
        event.add_booking(booking)
        attendee.add_booking(booking)
        self.bookings.append(booking)
        return booking

    def cancel_booking(self, reference: str) -> None:
        for booking in self.bookings:
            if booking.reference == reference:
                booking.cancel()
                return
        raise LookupError("Booking not found.")

    def event_report(self, event: Event) -> str:
        return f"{event}: {event.spaces_left()} space(s) left"
