# Q4 — Restaurant System

## Scenario

This starter application models a restaurant menu, tables and customer orders. It is intended to demonstrate abstraction, inheritance, composition and polymorphism while remaining small enough for a classroom exercise.

## Run it

Use Python 3.10 or later. From this folder, run:

```bash
python main.py
```

No packages need to be installed.

## Files

- `menu.py` — abstract menu items and their concrete types
- `restaurant.py` — tables, orders and the restaurant service
- `main.py` — a short demonstration

## Requirements to implement

1. Every menu item has a non-empty name and a price greater than zero.
2. Food and drink items must calculate their display descriptions through their own implementations.
3. A table can have no more than one open order at a time.
4. An order belongs to one table and starts open.
5. A closed order cannot be changed.
6. The bill must equal the combined prices of the items in that particular order.
7. Opening or closing an order must leave the table and restaurant in a consistent state.
8. The restaurant must be able to produce a useful description of a table and its current order.

Keep the example runnable and preserve the object-oriented style as you improve it.
